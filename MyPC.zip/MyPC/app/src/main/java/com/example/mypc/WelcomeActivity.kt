package com.example.mypc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class WelcomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)

        // Menemukan tombol Masuk
        val btnMasuk: Button = findViewById(R.id.btnMasuk)

        // Menambahkan listener klik pada tombol
        btnMasuk.setOnClickListener {
            // Pindah ke MainActivity saat tombol ditekan
            val intent = Intent(this@WelcomeActivity, MainActivity::class.java)
            startActivity(intent)
            finish() // Menutup WelcomeActivity agar tidak kembali
        }
    }
}
